from Run import Run

r = Run()
# r.run()
r.runOneStep()
r.runOneStep()
r.runOneStep()
r.runOneStep()
r.runOneStep()
r.runOneStep()
r.runOneStep()
r.runOneStep()
r.runOneStep()

r.runOneCycle()
